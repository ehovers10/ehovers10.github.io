Lucy's analogical reasoning

<p class="fragment">Primary analogues:</p>
<ul>
	<li class="fragment" >Tom's Chevy</li>
	<li class="fragment" >3 other friends with Tom's model/year also with good fuel economy</li>
	<li class="fragment" >An additional Chevy owner who gets poor fuel economy (counter-analogy)</li>
	<li class="fragment" >All analogues buy gas at same station, have same mechanic, and use same engine additives</li>
  <li class="fragment" >one of these factors could be the cause rather than the model/year type</li>

<p class="fragment">Secondary analogue:</p>
 <ul>
 	<li class="fragment" >A Chevy</li>

<p class="fragment" >Proposed property: Good fuel economy</p>
--"at least as good as Tom's"
--"exactly the same as Tom's"

<p class="fragment">Similarities</p>
--padded steering wheel, tachometer, fabric upholstery, tinted windows, premium sound system, white paint
--engine size, curb weight, aerodynamic body, gear ratio, tires

<p class="fragment">Disanalogy</p>
--Lucy's potential Chevy has a turbo charger, Lucy is an aggressive driver while Tom is conservative
--Tom's has the turbo charger, and he is the aggressive driver


